#!/usr/bin/env bash
# SubagentStop hook: log subagent completion to agent-feed.log.
# Appends timestamped entry for retrospective status tracking and
# crash recovery visibility.
# Input: JSON on stdin with subagent details.
# Always exits 0.

set -uo pipefail

# Read subagent event from stdin
input=$(cat)

# Validate JSON input — exit silently on malformed data
if ! echo "$input" | jq empty 2>/dev/null; then
  exit 0
fi

# Extract fields from the actual SubagentStop payload
agent_id=$(echo "$input" | jq -r '.agent_id // "unknown"' 2>/dev/null)
agent_type=$(echo "$input" | jq -r '.agent_type // "unknown"' 2>/dev/null)
session_id=$(echo "$input" | jq -r '.session_id // "unknown"' 2>/dev/null)
cwd=$(echo "$input" | jq -r '.cwd // ""' 2>/dev/null)
last_msg=$(echo "$input" | jq -r '.last_assistant_message // ""' 2>/dev/null | head -c 200)

# Derive project from cwd
project=""
if [[ -n "$cwd" ]]; then
    project=$(basename "$cwd" 2>/dev/null || true)
fi

# Determine the feed log location.
# Project-level: .rdf/work-output/agent-feed.log (inside work-output, project-scoped)
# Workspace-level: ./.rdf/agent-feed.log (flat, when cwd is a workspace root)
# Fallback: ~/.rdf/agent-feed.log (machine-global; no hardcoded paths)
feed_log=""
if [[ -d "./.rdf/work-output" ]]; then
    feed_log="./.rdf/work-output/agent-feed.log"
elif [[ -d "./.rdf" ]]; then
    feed_log="./.rdf/agent-feed.log"
else
    [[ -z "${HOME:-}" ]] && exit 0   # hooks must never error; no HOME means nowhere safe to log
    command mkdir -p "${HOME}/.rdf"
    feed_log="${HOME}/.rdf/agent-feed.log"
fi
timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')

# Build log entry
entry="${timestamp} | AGENT_STOP | type=${agent_type} | project=${project} | id=${agent_id} | session=${session_id}"
if [[ -n "${last_msg:-}" ]]; then
    # Sanitize: collapse newlines to spaces for single-line log
    clean_msg=$(echo "$last_msg" | tr '\n' ' ' | sed 's/  */ /g')
    entry="${entry} | preview=${clean_msg}"
fi

# Size cap: same 100 KB / 1000-line contract as rotate-work-output.sh —
# the ~/.rdf fallback has no other rotation path
if [[ -f "$feed_log" ]] && [[ "$(command wc -c < "$feed_log" 2>/dev/null || echo 0)" -gt 102400 ]]; then  # unreadable log → treat as size 0, skip rotation
    rotate_tmp="$(command mktemp "${feed_log}.tmp.XXXXXX" 2>/dev/null || echo "")"  # mktemp failure → skip rotation; unique name avoids concurrent-hook races
    if [[ -n "$rotate_tmp" ]]; then
        command tail -n 1000 "$feed_log" > "$rotate_tmp" 2>/dev/null && command mv "$rotate_tmp" "$feed_log"  # rotation failure is non-fatal — hook must never error
        command rm -f "$rotate_tmp" 2>/dev/null  # leftover only if the mv failed; ignore errors
    fi
fi

# Append to feed log
echo "$entry" >> "$feed_log"

exit 0
